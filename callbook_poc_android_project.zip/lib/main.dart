import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(CallbookApp());
}

class CallbookApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Callbook POC Indonesia',
      theme: ThemeData.dark().copyWith(
        primaryColor: Colors.blueAccent,
        scaffoldBackgroundColor: Colors.black,
        textTheme: ThemeData.dark().textTheme.apply(fontFamily: 'Roboto'),
      ),
      home: LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}